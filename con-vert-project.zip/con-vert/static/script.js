const conversions = {
    length: [
        "Meters to Feet",
        "Feet to Meters",
        "Kilometers to Miles",
        "Miles to Kilometers"
    ],
    weight: [
        "Kilograms to Pounds",
        "Pounds to Kilograms",
        "Grams to Ounces",
        "Ounces to Grams"
    ],
    temperature: [
        "Celsius to Fahrenheit",
        "Fahrenheit to Celsius",
        "Celsius to Kelvin",
        "Kelvin to Celsius"
    ],
    time: [
        "Hours to Minutes",
        "Minutes to Hours",
        "Days to Weeks",
        "Weeks to Days",
        "Days to Months",
        "Months to Days"
    ],
    speed: [
        "Km/h to Mph",
        "Mph to Km/h",
        "M/s to Ft/s",
        "Ft/s to M/s"
    ],
    volume: [
        "Liters to Gallons",
        "Gallons to Liters",
        "Milliliters to Fluid Ounces",
        "Fluid Ounces to Milliliters"
    ]
};

const category = document.getElementById("category");
const conversion = document.getElementById("conversion");
const valueInput = document.getElementById("value");
const result = document.getElementById("result");

function updateConversions() {
    const selectedCategory = category.value;
    conversion.innerHTML = "";

    conversions[selectedCategory].forEach(option => {
        const newOption = document.createElement("option");
        newOption.value = option;
        newOption.textContent = option;
        conversion.appendChild(newOption);
    });

    result.textContent = "Your result will appear here.";
}

async function convert() {
    const rawValue = valueInput.value;

    if (rawValue.trim() === "" || !Number.isFinite(Number(rawValue))) {
        result.textContent = "Please enter a valid number.";
        return;
    }

    result.textContent = "Converting...";

    try {
        const response = await fetch("/convert", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                category: category.value,
                conversion: conversion.value,
                value: rawValue
            })
        });

        const data = await response.json();

        if (!response.ok) {
            result.textContent = data.error || "Conversion failed.";
            return;
        }

        result.textContent =
            `${data.input} → ${data.result.toFixed(2)} (${data.conversion})`;

    } catch (error) {
        result.textContent = "Unable to connect to the Python backend.";
    }
}

function clearFields() {
    valueInput.value = "";
    category.selectedIndex = 0;
    updateConversions();
}

category.addEventListener("change", updateConversions);
document.getElementById("convert-button").addEventListener("click", convert);
document.getElementById("clear-button").addEventListener("click", clearFields);

valueInput.addEventListener("keydown", event => {
    if (event.key === "Enter") {
        convert();
    }
});

updateConversions();
